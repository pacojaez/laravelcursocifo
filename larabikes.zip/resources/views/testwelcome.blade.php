@extends('layout.test')

@section('titulo', 'Test de Larabikes')

@section('contenido')
    <x-testcomponent>
        aquí iré imprimiendo los resultados de las pruebas
    </x-testcomponent>
@endsection


