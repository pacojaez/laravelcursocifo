@extends('layout.master')

@section('titulo', 'Instalación de Larabikes')

@section('contenido')
 <p>hello</p>
@endsection
