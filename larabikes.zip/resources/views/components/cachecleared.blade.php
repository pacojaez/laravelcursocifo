@extends('layout.test')

@section('titulo', 'Cache borrada')

@section('contenido')
    <x-testcomponent>
        The cache has been correctly cleared!!!
    </x-testcomponent>
@endsection
