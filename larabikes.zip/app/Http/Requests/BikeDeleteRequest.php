<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BikeDeleteRequest extends BikeRequest
{
    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [];
    }
}
