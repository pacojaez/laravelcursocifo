<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ConcesionarioSeeder extends Seeder
{
    public function run()
    {
        //
    }
}
